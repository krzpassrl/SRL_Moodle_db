FPDI
==================================

No changes from the upstream version have been made. Both FPDI and FPDF_TPL have
been downloaded and unzipped to this directory.

Information
-----------

URL: http://www.setasign.de/products/pdf-php-solutions/fpdi/
Download from: http://www.setasign.de/products/pdf-php-solutions/fpdi/downloads
Documentation: http://www.setasign.de/products/pdf-php-solutions/fpdi/manuals/
License: Apache Software License 2.0

Downloaded versions:
FPDI: 1.4.4
FPDF_TPL: 1.2.3
